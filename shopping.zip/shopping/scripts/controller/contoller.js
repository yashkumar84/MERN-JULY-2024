import { doNetworkCall } from "../services/api-client.js";

window.addEventListener("load", initEvents);
let container;
const getData = async () => {
  const data = await doNetworkCall();
  return data;
};

async function initEvents() {
  container = document.getElementById("container");
  const data = await getData();
  showCards(data);
}

function showCards(data) {
  data.map((obj) => printCard(obj));
}

function printCard(obj) {
  const card = `<div class="card" style="width: 18rem; height: 500px;">
  <img height="300px" src=${obj.image} class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">${obj.title.substring(0, 15)}</h5>
    <p class="card-text">${obj.description.substring(0, 51)}</p>
    <h5 class="card-title">₹ ${obj.price}</h5>
    <a href="#" class="btn btn-primary">Buy Now</a>
  </div>
</div>`;

  container.innerHTML += card;
}
