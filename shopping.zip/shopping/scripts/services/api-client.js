import { Product } from "../models/model.js";

export const doNetworkCall = async () => {
  try {
    const response = await fetch("https://fakestoreapi.com/products");
    let data = await response.json();
    console.log("data", data);
    data = data.map(
      (product) =>
        new Product(
          product.id,
          product.title,
          product.description,
          product.image,
          product.price
        )
    );
    return data;
  } catch (err) {
    console.log("error occurs", err);
  }
};
