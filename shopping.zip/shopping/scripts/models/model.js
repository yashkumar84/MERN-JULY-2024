export class Product {
  constructor(id, title, description, image, price) {
    this.id = id;
    this.description = description;
    this.title = title;
    this.image = image;
    this.price = price;
  }
}
