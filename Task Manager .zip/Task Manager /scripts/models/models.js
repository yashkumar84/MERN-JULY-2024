export class TaskModel {
  constructor({ id, name, description, date, priority, color }) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.date = date;
    this.priority = priority;
    this.color = color;
  }
}
